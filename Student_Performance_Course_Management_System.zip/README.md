# Student Performance & Course Management System

## Project Overview
This MySQL project manages student details, course information, enrollments, marks, and grades in a structured relational database.

## Objective
To organize student and academic records and make it easier to retrieve enrollment details and analyse student performance.

## Database Tables
- **Student** – stores student details.
- **Course** – stores course names and credit information.
- **Enrollment** – connects students with the courses they take.
- **Performance** – stores marks and grades for each enrollment.

## SQL Concepts Used
- CREATE TABLE and INSERT
- Primary keys and foreign keys
- Constraints and UNIQUE
- SELECT and WHERE
- INNER JOIN and LEFT JOIN
- GROUP BY and HAVING
- Aggregate functions: COUNT, AVG, MAX
- ORDER BY

## How to Run
1. Open MySQL Workbench.
2. Open `student_performance.sql`.
3. Execute the script.
4. The database `student_performance_db` and its sample records will be created.
5. Run the report queries at the end of the script to view the results.

## Note
The names and records in this project are sample data created for learning and demonstration.
