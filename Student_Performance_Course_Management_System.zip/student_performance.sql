-- Student Performance & Course Management System
-- Database: MySQL 8.0+

CREATE DATABASE IF NOT EXISTS student_performance_db;
USE student_performance_db;

DROP TABLE IF EXISTS Performance;
DROP TABLE IF EXISTS Enrollment;
DROP TABLE IF EXISTS Course;
DROP TABLE IF EXISTS Student;

CREATE TABLE Student (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE,
    department VARCHAR(80),
    year_of_study INT
);

CREATE TABLE Course (
    course_id INT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL,
    credits INT NOT NULL
);

CREATE TABLE Enrollment (
    enrollment_id INT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date DATE,
    FOREIGN KEY (student_id) REFERENCES Student(student_id),
    FOREIGN KEY (course_id) REFERENCES Course(course_id),
    UNIQUE (student_id, course_id)
);

CREATE TABLE Performance (
    performance_id INT PRIMARY KEY,
    enrollment_id INT NOT NULL,
    marks DECIMAL(5,2) NOT NULL,
    grade VARCHAR(2) NOT NULL,
    FOREIGN KEY (enrollment_id) REFERENCES Enrollment(enrollment_id),
    CHECK (marks BETWEEN 0 AND 100)
);

-- Sample student records
INSERT INTO Student VALUES
(1, 'Arun Kumar', 'arun@example.com', 'Computer Science', 3),
(2, 'Priya S', 'priya@example.com', 'Information Technology', 3),
(3, 'Kavin R', 'kavin@example.com', 'Computer Science', 2),
(4, 'Meena T', 'meena@example.com', 'Biotechnology', 3),
(5, 'Rahul M', 'rahul@example.com', 'Information Technology', 2);

-- Sample courses
INSERT INTO Course VALUES
(101, 'Database Management Systems', 4),
(102, 'Python Programming', 3),
(103, 'Web Development', 3);

-- Student-course enrollment
INSERT INTO Enrollment VALUES
(1001, 1, 101, '2026-07-01'),
(1002, 1, 102, '2026-07-01'),
(1003, 2, 101, '2026-07-02'),
(1004, 2, 103, '2026-07-02'),
(1005, 3, 102, '2026-07-03'),
(1006, 4, 101, '2026-07-03'),
(1007, 5, 103, '2026-07-04');

-- Marks and grades
INSERT INTO Performance VALUES
(1, 1001, 86, 'A'),
(2, 1002, 92, 'A+'),
(3, 1003, 78, 'B+'),
(4, 1004, 88, 'A'),
(5, 1005, 69, 'B'),
(6, 1006, 95, 'A+'),
(7, 1007, 73, 'B');

-- 1. Display all students
SELECT * FROM Student;

-- 2. Display students from Computer Science
SELECT * FROM Student
WHERE department = 'Computer Science';

-- 3. Show students and their enrolled courses
SELECT s.student_name, c.course_name, e.enrollment_date
FROM Student s
JOIN Enrollment e ON s.student_id = e.student_id
JOIN Course c ON e.course_id = c.course_id
ORDER BY s.student_name;

-- 4. Show marks and grades for each student and course
SELECT s.student_name, c.course_name, p.marks, p.grade
FROM Student s
JOIN Enrollment e ON s.student_id = e.student_id
JOIN Course c ON e.course_id = c.course_id
JOIN Performance p ON e.enrollment_id = p.enrollment_id
ORDER BY s.student_name, c.course_name;

-- 5. Calculate average marks for each course
SELECT c.course_name, ROUND(AVG(p.marks), 2) AS average_marks
FROM Course c
JOIN Enrollment e ON c.course_id = e.course_id
JOIN Performance p ON e.enrollment_id = p.enrollment_id
GROUP BY c.course_id, c.course_name;

-- 6. Count students enrolled in each course
SELECT c.course_name, COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrollment e ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_name;

-- 7. Find students who scored 80 or above
SELECT s.student_name, c.course_name, p.marks
FROM Student s
JOIN Enrollment e ON s.student_id = e.student_id
JOIN Course c ON e.course_id = c.course_id
JOIN Performance p ON e.enrollment_id = p.enrollment_id
WHERE p.marks >= 80;

-- 8. Find courses with an average mark above 80
SELECT c.course_name, ROUND(AVG(p.marks), 2) AS average_marks
FROM Course c
JOIN Enrollment e ON c.course_id = e.course_id
JOIN Performance p ON e.enrollment_id = p.enrollment_id
GROUP BY c.course_id, c.course_name
HAVING AVG(p.marks) > 80;

-- 9. Display the highest mark
SELECT MAX(marks) AS highest_mark FROM Performance;

-- 10. Calculate each student's average mark
SELECT s.student_name, ROUND(AVG(p.marks), 2) AS average_marks
FROM Student s
JOIN Enrollment e ON s.student_id = e.student_id
JOIN Performance p ON e.enrollment_id = p.enrollment_id
GROUP BY s.student_id, s.student_name
ORDER BY average_marks DESC;
